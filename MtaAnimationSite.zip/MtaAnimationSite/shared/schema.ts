import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Series table
export const series = pgTable("series", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Episodes table
export const episodes = pgTable("episodes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  thumbnailUrl: text("thumbnail_url").notNull(),
  videoUrl: text("video_url").notNull(),
  duration: text("duration").notNull(),
  releaseDate: text("release_date").notNull(),
  seriesName: text("series_name").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Characters table
export const characters = pgTable("characters", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  seriesName: text("series_name").notNull(),
  color: text("color").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Blog posts table
export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  excerpt: text("excerpt").notNull(),
  content: text("content").notNull(),
  thumbnailUrl: text("thumbnail_url").notNull(),
  category: text("category").notNull(),
  date: text("date").notNull(),
  author: text("author").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Define relations between tables
export const seriesRelations = relations(series, ({ many }) => ({
  episodes: many(episodes),
  characters: many(characters),
}));

export const episodesRelations = relations(episodes, ({ one }) => ({
  series: one(series, {
    fields: [episodes.seriesName],
    references: [series.name],
  }),
}));

export const charactersRelations = relations(characters, ({ one }) => ({
  series: one(series, {
    fields: [characters.seriesName],
    references: [series.name],
  }),
}));

// Validation schemas for series
export const seriesInsertSchema = createInsertSchema(series, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters"),
  description: (schema) => schema.min(10, "Description must be at least 10 characters"),
});
export type SeriesInsert = z.infer<typeof seriesInsertSchema>;
export type Series = typeof series.$inferSelect;

// Validation schemas for episodes
export const episodesInsertSchema = createInsertSchema(episodes, {
  title: (schema) => schema.min(3, "Title must be at least 3 characters"),
  description: (schema) => schema.min(10, "Description must be at least 10 characters"),
});
export type EpisodeInsert = z.infer<typeof episodesInsertSchema>;
export type Episode = typeof episodes.$inferSelect;

// Validation schemas for characters
export const charactersInsertSchema = createInsertSchema(characters, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters"),
  description: (schema) => schema.min(10, "Description must be at least 10 characters"),
});
export type CharacterInsert = z.infer<typeof charactersInsertSchema>;
export type Character = typeof characters.$inferSelect;

// Validation schemas for blog posts
export const blogPostsInsertSchema = createInsertSchema(blogPosts, {
  title: (schema) => schema.min(3, "Title must be at least 3 characters"),
  excerpt: (schema) => schema.min(10, "Excerpt must be at least 10 characters"),
  content: (schema) => schema.min(50, "Content must be at least 50 characters"),
});
export type BlogPostInsert = z.infer<typeof blogPostsInsertSchema>;
export type BlogPost = typeof blogPosts.$inferSelect;

// Users table (keeping this for authentication if needed later)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users, {
  username: (schema) => schema.min(3, "Username must be at least 3 characters"),
  password: (schema) => schema.min(6, "Password must be at least 6 characters"),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
