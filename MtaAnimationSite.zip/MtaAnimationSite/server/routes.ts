import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { db } from "@db";
import { 
  series, episodes, characters, blogPosts, users,
  seriesInsertSchema, episodesInsertSchema, charactersInsertSchema, blogPostsInsertSchema 
} from "@shared/schema";
import { eq } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes for frontend
  
  // General endpoint to check API status
  app.get('/api', (req: Request, res: Response) => {
    return res.status(200).json({ status: 'API is running' });
  });

  // Series endpoints
  app.get('/api/series', async (req: Request, res: Response) => {
    try {
      const allSeries = await db.select().from(series);
      return res.json(allSeries);
    } catch (error) {
      console.error('Error fetching series:', error);
      return res.status(500).json({ error: 'Failed to fetch series' });
    }
  });

  app.get('/api/series/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const seriesItem = await db.select().from(series).where(eq(series.id, parseInt(id))).limit(1);
      
      if (seriesItem.length === 0) {
        return res.status(404).json({ error: 'Series not found' });
      }
      
      return res.json(seriesItem[0]);
    } catch (error) {
      console.error('Error fetching series by ID:', error);
      return res.status(500).json({ error: 'Failed to fetch series' });
    }
  });

  // Episodes endpoints
  app.get('/api/episodes', async (req: Request, res: Response) => {
    try {
      const allEpisodes = await db.select().from(episodes);
      return res.json(allEpisodes);
    } catch (error) {
      console.error('Error fetching episodes:', error);
      return res.status(500).json({ error: 'Failed to fetch episodes' });
    }
  });

  app.get('/api/episodes/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const episode = await db.select().from(episodes).where(eq(episodes.id, parseInt(id))).limit(1);
      
      if (episode.length === 0) {
        return res.status(404).json({ error: 'Episode not found' });
      }
      
      return res.json(episode[0]);
    } catch (error) {
      console.error('Error fetching episode by ID:', error);
      return res.status(500).json({ error: 'Failed to fetch episode' });
    }
  });

  // Characters endpoints
  app.get('/api/characters', async (req: Request, res: Response) => {
    try {
      const allCharacters = await db.select().from(characters);
      return res.json(allCharacters);
    } catch (error) {
      console.error('Error fetching characters:', error);
      return res.status(500).json({ error: 'Failed to fetch characters' });
    }
  });

  app.get('/api/characters/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const character = await db.select().from(characters).where(eq(characters.id, parseInt(id))).limit(1);
      
      if (character.length === 0) {
        return res.status(404).json({ error: 'Character not found' });
      }
      
      return res.json(character[0]);
    } catch (error) {
      console.error('Error fetching character by ID:', error);
      return res.status(500).json({ error: 'Failed to fetch character' });
    }
  });

  // Blog posts endpoints
  app.get('/api/blog-posts', async (req: Request, res: Response) => {
    try {
      const allBlogPosts = await db.select().from(blogPosts);
      return res.json(allBlogPosts);
    } catch (error) {
      console.error('Error fetching blog posts:', error);
      return res.status(500).json({ error: 'Failed to fetch blog posts' });
    }
  });

  app.get('/api/blog-posts/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const blogPost = await db.select().from(blogPosts).where(eq(blogPosts.id, parseInt(id))).limit(1);
      
      if (blogPost.length === 0) {
        return res.status(404).json({ error: 'Blog post not found' });
      }
      
      return res.json(blogPost[0]);
    } catch (error) {
      console.error('Error fetching blog post by ID:', error);
      return res.status(500).json({ error: 'Failed to fetch blog post' });
    }
  });

  // Admin API endpoints for content management
  // These will be secured in the next implementation phase

  // Series admin endpoints
  app.post('/api/admin/series', async (req: Request, res: Response) => {
    try {
      const validatedData = seriesInsertSchema.parse(req.body);
      const newSeries = await db.insert(series).values(validatedData).returning();
      return res.status(201).json(newSeries[0]);
    } catch (error) {
      console.error('Error creating series:', error);
      return res.status(500).json({ error: 'Failed to create series' });
    }
  });

  app.put('/api/admin/series/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const validatedData = seriesInsertSchema.parse(req.body);
      
      const updatedSeries = await db
        .update(series)
        .set(validatedData)
        .where(eq(series.id, parseInt(id)))
        .returning();
      
      if (updatedSeries.length === 0) {
        return res.status(404).json({ error: 'Series not found' });
      }
      
      return res.json(updatedSeries[0]);
    } catch (error) {
      console.error('Error updating series:', error);
      return res.status(500).json({ error: 'Failed to update series' });
    }
  });

  app.delete('/api/admin/series/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const deleted = await db
        .delete(series)
        .where(eq(series.id, parseInt(id)))
        .returning();
      
      if (deleted.length === 0) {
        return res.status(404).json({ error: 'Series not found' });
      }
      
      return res.json({ message: 'Series deleted successfully' });
    } catch (error) {
      console.error('Error deleting series:', error);
      return res.status(500).json({ error: 'Failed to delete series' });
    }
  });

  // Episodes admin endpoints
  app.post('/api/admin/episodes', async (req: Request, res: Response) => {
    try {
      const validatedData = episodesInsertSchema.parse(req.body);
      const newEpisode = await db.insert(episodes).values(validatedData).returning();
      return res.status(201).json(newEpisode[0]);
    } catch (error) {
      console.error('Error creating episode:', error);
      return res.status(500).json({ error: 'Failed to create episode' });
    }
  });

  app.put('/api/admin/episodes/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const validatedData = episodesInsertSchema.parse(req.body);
      
      const updatedEpisode = await db
        .update(episodes)
        .set(validatedData)
        .where(eq(episodes.id, parseInt(id)))
        .returning();
      
      if (updatedEpisode.length === 0) {
        return res.status(404).json({ error: 'Episode not found' });
      }
      
      return res.json(updatedEpisode[0]);
    } catch (error) {
      console.error('Error updating episode:', error);
      return res.status(500).json({ error: 'Failed to update episode' });
    }
  });

  app.delete('/api/admin/episodes/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const deleted = await db
        .delete(episodes)
        .where(eq(episodes.id, parseInt(id)))
        .returning();
      
      if (deleted.length === 0) {
        return res.status(404).json({ error: 'Episode not found' });
      }
      
      return res.json({ message: 'Episode deleted successfully' });
    } catch (error) {
      console.error('Error deleting episode:', error);
      return res.status(500).json({ error: 'Failed to delete episode' });
    }
  });

  // Characters admin endpoints
  app.post('/api/admin/characters', async (req: Request, res: Response) => {
    try {
      const validatedData = charactersInsertSchema.parse(req.body);
      const newCharacter = await db.insert(characters).values(validatedData).returning();
      return res.status(201).json(newCharacter[0]);
    } catch (error) {
      console.error('Error creating character:', error);
      return res.status(500).json({ error: 'Failed to create character' });
    }
  });

  app.put('/api/admin/characters/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const validatedData = charactersInsertSchema.parse(req.body);
      
      const updatedCharacter = await db
        .update(characters)
        .set(validatedData)
        .where(eq(characters.id, parseInt(id)))
        .returning();
      
      if (updatedCharacter.length === 0) {
        return res.status(404).json({ error: 'Character not found' });
      }
      
      return res.json(updatedCharacter[0]);
    } catch (error) {
      console.error('Error updating character:', error);
      return res.status(500).json({ error: 'Failed to update character' });
    }
  });

  app.delete('/api/admin/characters/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const deleted = await db
        .delete(characters)
        .where(eq(characters.id, parseInt(id)))
        .returning();
      
      if (deleted.length === 0) {
        return res.status(404).json({ error: 'Character not found' });
      }
      
      return res.json({ message: 'Character deleted successfully' });
    } catch (error) {
      console.error('Error deleting character:', error);
      return res.status(500).json({ error: 'Failed to delete character' });
    }
  });

  // Blog posts admin endpoints
  app.post('/api/admin/blog-posts', async (req: Request, res: Response) => {
    try {
      const validatedData = blogPostsInsertSchema.parse(req.body);
      const newBlogPost = await db.insert(blogPosts).values(validatedData).returning();
      return res.status(201).json(newBlogPost[0]);
    } catch (error) {
      console.error('Error creating blog post:', error);
      return res.status(500).json({ error: 'Failed to create blog post' });
    }
  });

  app.put('/api/admin/blog-posts/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const validatedData = blogPostsInsertSchema.parse(req.body);
      
      const updatedBlogPost = await db
        .update(blogPosts)
        .set(validatedData)
        .where(eq(blogPosts.id, parseInt(id)))
        .returning();
      
      if (updatedBlogPost.length === 0) {
        return res.status(404).json({ error: 'Blog post not found' });
      }
      
      return res.json(updatedBlogPost[0]);
    } catch (error) {
      console.error('Error updating blog post:', error);
      return res.status(500).json({ error: 'Failed to update blog post' });
    }
  });

  app.delete('/api/admin/blog-posts/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      
      const deleted = await db
        .delete(blogPosts)
        .where(eq(blogPosts.id, parseInt(id)))
        .returning();
      
      if (deleted.length === 0) {
        return res.status(404).json({ error: 'Blog post not found' });
      }
      
      return res.json({ message: 'Blog post deleted successfully' });
    } catch (error) {
      console.error('Error deleting blog post:', error);
      return res.status(500).json({ error: 'Failed to delete blog post' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
