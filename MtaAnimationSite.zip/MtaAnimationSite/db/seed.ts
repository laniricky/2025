import { db } from "./index";
import * as schema from "@shared/schema";

async function seed() {
  try {
    console.log("Starting database seeding process...");
    
    // Series data
    const seriesData = [
      {
        name: "The Lost Kingdom",
        description: "An epic adventure series following a team of explorers as they uncover ancient mysteries and battle supernatural forces."
      },
      {
        name: "Cosmic Adventures",
        description: "A space-themed animation following intergalactic explorers as they travel across galaxies and discover new civilizations."
      },
      {
        name: "Mythical Creatures",
        description: "A series exploring the world of legendary creatures and the humans who encounter them."
      },
      {
        name: "Urban Legends",
        description: "Modern tales set in bustling cities where ordinary people encounter extraordinary circumstances."
      }
    ];

    // Episodes data
    const episodesData = [
      {
        title: "The Lost Kingdom: Episode 14",
        description: "The heroes face their greatest challenge yet as they venture deep into the forgotten temple.",
        thumbnailUrl: "https://images.unsplash.com/photo-1634986666676-ec8fd927c23d?q=80&w=800",
        videoUrl: "https://example.com/videos/episode-14.mp4",
        duration: "24:15",
        releaseDate: "2023-03-15",
        seriesName: "The Lost Kingdom"
      },
      {
        title: "The Lost Kingdom: Episode 13",
        description: "Secrets are revealed as the ancient map leads our heroes to a mysterious island.",
        thumbnailUrl: "https://images.unsplash.com/photo-1518998053901-5348d3961a04?q=80&w=400",
        videoUrl: "https://example.com/videos/episode-13.mp4",
        duration: "21:42",
        releaseDate: "2023-03-01",
        seriesName: "The Lost Kingdom"
      },
      {
        title: "The Lost Kingdom: Episode 12",
        description: "The team must navigate through treacherous waters as they continue their quest.",
        thumbnailUrl: "https://images.unsplash.com/photo-1599420186946-7b6fb4e297f0?q=80&w=400",
        videoUrl: "https://example.com/videos/episode-12.mp4",
        duration: "22:08",
        releaseDate: "2023-02-15",
        seriesName: "The Lost Kingdom"
      },
      {
        title: "The Lost Kingdom: Episode 11",
        description: "A new ally joins the quest as our heroes face unexpected dangers in the forest.",
        thumbnailUrl: "https://images.unsplash.com/photo-1574267432644-f410f8ec2474?q=80&w=400",
        videoUrl: "https://example.com/videos/episode-11.mp4",
        duration: "23:55",
        releaseDate: "2023-02-01",
        seriesName: "The Lost Kingdom"
      },
      {
        title: "Cosmic Adventures: Episode 8",
        description: "The crew encounters a mysterious space anomaly that threatens their ship.",
        thumbnailUrl: "https://images.unsplash.com/photo-1608178398319-48f814d0750c?q=80&w=400",
        videoUrl: "https://example.com/videos/cosmic-episode-8.mp4",
        duration: "22:30",
        releaseDate: "2023-01-15",
        seriesName: "Cosmic Adventures"
      },
      {
        title: "Cosmic Adventures: Episode 7",
        description: "A diplomatic mission to an alien world takes an unexpected turn.",
        thumbnailUrl: "https://images.unsplash.com/photo-1614732414444-096e5f1122d5?q=80&w=400",
        videoUrl: "https://example.com/videos/cosmic-episode-7.mp4",
        duration: "23:15",
        releaseDate: "2023-01-01",
        seriesName: "Cosmic Adventures"
      },
      {
        title: "Mythical Creatures: Episode 5",
        description: "The team encounters a legendary phoenix in the mountains of a remote region.",
        thumbnailUrl: "https://images.unsplash.com/photo-1640499900704-b00dd6a1103a?q=80&w=400",
        videoUrl: "https://example.com/videos/mythical-episode-5.mp4",
        duration: "21:10",
        releaseDate: "2022-12-15",
        seriesName: "Mythical Creatures"
      },
      {
        title: "Urban Legends: Episode 3",
        description: "A mysterious figure appears in the city's subway system, leaving cryptic messages.",
        thumbnailUrl: "https://images.unsplash.com/photo-1557682250-26d6bcc4631c?q=80&w=400",
        videoUrl: "https://example.com/videos/urban-episode-3.mp4",
        duration: "24:45",
        releaseDate: "2022-12-01",
        seriesName: "Urban Legends"
      }
    ];

    // Characters data
    const charactersData = [
      {
        name: "Lyra Moonwhisper",
        role: "The Enchantress",
        description: "A skilled sorceress with the ability to communicate with spirits, Lyra is the mystical heart of the team.",
        imageUrl: "https://images.unsplash.com/photo-1580477667995-2b94f01c9516?q=80&w=300",
        seriesName: "The Lost Kingdom",
        color: "primary"
      },
      {
        name: "Kael Fireforge",
        role: "The Warrior",
        description: "A formidable fighter with a mysterious past, Kael's strength and tactical genius are invaluable to the team.",
        imageUrl: "https://images.unsplash.com/photo-1626197031507-c17099753214?q=80&w=300",
        seriesName: "The Lost Kingdom",
        color: "secondary"
      },
      {
        name: "Zephyr Swiftwind",
        role: "The Scout",
        description: "Nimble and perceptive, Zephyr's ability to navigate difficult terrain and spot danger makes him indispensable.",
        imageUrl: "https://images.unsplash.com/photo-1599420186946-7b6fb4e297f0?q=80&w=300",
        seriesName: "The Lost Kingdom",
        color: "accent"
      },
      {
        name: "Thorne Shadowblade",
        role: "The Rogue",
        description: "A master of stealth and deception, Thorne's skills are essential for overcoming the many traps and puzzles the team encounters.",
        imageUrl: "https://images.unsplash.com/photo-1536007164800-b7f11331f35c?q=80&w=300",
        seriesName: "The Lost Kingdom",
        color: "primary"
      },
      {
        name: "Captain Nova",
        role: "Expedition Leader",
        description: "The brave and determined leader of the Cosmic Voyager spaceship, with years of experience navigating interstellar space.",
        imageUrl: "https://images.unsplash.com/photo-1569003339405-ea396a5a8a90?q=80&w=300",
        seriesName: "Cosmic Adventures",
        color: "secondary"
      },
      {
        name: "Dr. Orion",
        role: "Chief Scientist",
        description: "A brilliant astrophysicist who specializes in quantum mechanics and alien biology, always seeking new discoveries.",
        imageUrl: "https://images.unsplash.com/photo-1607990281513-2c110a25bd8c?q=80&w=300",
        seriesName: "Cosmic Adventures",
        color: "accent"
      },
      {
        name: "Fae the Griffin",
        role: "Guardian of the Skies",
        description: "A majestic griffin who protects the aerial realms and has formed an unlikely alliance with humans.",
        imageUrl: "https://images.unsplash.com/photo-1589595363745-d842812a9db7?q=80&w=300",
        seriesName: "Mythical Creatures",
        color: "primary"
      },
      {
        name: "Detective Vance",
        role: "Paranormal Investigator",
        description: "A skeptical detective who gradually becomes convinced of supernatural phenomena as he investigates urban mysteries.",
        imageUrl: "https://images.unsplash.com/photo-1600486913747-55e5470d6f40?q=80&w=300",
        seriesName: "Urban Legends",
        color: "secondary"
      }
    ];

    // Blog posts data
    const blogPostsData = [
      {
        title: "Behind the Scenes: Creating The Lost Kingdom",
        excerpt: "Dive into our creative process and discover how we bring our characters to life through animation.",
        content: "In this first installment of our behind-the-scenes series, we take you through the journey of creating 'The Lost Kingdom'. From initial concept sketches to final rendering, our team of artists and animators work tirelessly to bring this fantastical world to life.\n\nOne of the biggest challenges we faced was designing the ancient temple environments. Our art team spent weeks researching archaeological sites and ancient architectural styles to create something that felt both authentic and magical. Each pillar, statue, and stone was meticulously crafted to tell its own story within the larger narrative.\n\nCharacter animation presented another exciting challenge. Characters like Lyra Moonwhisper required special attention to her magical effects and flowing movements. Our animation team developed new techniques to capture the ethereal quality of her spellcasting, using a combination of traditional animation principles and cutting-edge digital tools.\n\nThe voice recording sessions were equally fascinating, with our talented voice actors bringing unexpected depths to their characters. Many of the most memorable lines in the series actually came from improvisation during these sessions!\n\nWe hope this glimpse into our creative process enhances your appreciation for the show and we look forward to sharing more behind-the-scenes insights in future posts.",
        thumbnailUrl: "https://images.unsplash.com/photo-1600132806370-bf17e65e942f?q=80&w=400",
        category: "Animation Process",
        date: "2023-03-10",
        author: "Fredrick Lani"
      },
      {
        title: "Designing Memorable Characters: Our Approach",
        excerpt: "Learn about our character design philosophy and how we create memorable personalities for our animations.",
        content: "Creating characters that resonate with audiences is perhaps the most crucial aspect of animation storytelling. At Mtaanimation, we follow a character-first approach that prioritizes personality, motivation, and growth potential over visual appeal alone.\n\nOur character design process begins with extensive discussions about the character's role in the story, their background, desires, fears, and relationships. Only after establishing these foundational elements do we begin sketching visual concepts.\n\nWe believe that the most memorable characters have clearly defined silhouettes that make them instantly recognizable. Notice how you can identify Kael Fireforge merely from his outline? This is intentional and helps create iconic characters that stand out in viewers' minds.\n\nAnother key principle we follow is ensuring that a character's design reflects their personality and backstory. Thorne Shadowblade's costume incorporates elements that hint at his mysterious past, while Lyra's attire integrates symbols related to her mystical abilities.\n\nColor theory plays a vital role as well. Each character has a signature color palette that corresponds to their personality traits and emotional journey. These colors are consistently referenced throughout the series in environments and lighting when these characters face significant moments.\n\nFinally, we put every character design through what we call the 'merchandise test' - can this character be effectively translated into different media and merchandise? While this might seem commercial, it actually helps us ensure that our designs are versatile, distinctive, and appealing from multiple angles.\n\nThrough this thoughtful approach to character design, we strive to create personalities that viewers connect with on a deeper level, making their journeys through our animated worlds more meaningful and engaging.",
        thumbnailUrl: "https://images.unsplash.com/photo-1626785774573-4b799315345d?q=80&w=400",
        category: "Character Design",
        date: "2023-02-25",
        author: "Maya Chen"
      },
      {
        title: "Mtaanimation Wins Best Animated Series Award",
        excerpt: "We're thrilled to announce that The Lost Kingdom has won the prestigious Global Animation Award.",
        content: "We have exciting news to share with our community! 'The Lost Kingdom' has been awarded the prestigious Global Animation Award for Best Animated Series of 2023.\n\nThe announcement came during the annual Global Animation Festival held virtually this year with participants from over 40 countries. The judges praised the series for its \"innovative storytelling, stunning visual style, and rich character development,\" describing it as \"a new benchmark in animated adventure series.\"\n\nIn his acceptance speech, our founder and creative director Fredrick Lani thanked the talented team behind the series: \"This award belongs to every artist, animator, writer, voice actor, and production staff member who poured their heart and soul into creating 'The Lost Kingdom.' Their dedication, creativity, and passion are what made this series special.\"\n\nLani also expressed gratitude to the fans: \"And most importantly, thank you to our amazing audience who joined us on this journey. Your enthusiasm and support inspire us to keep pushing the boundaries of animation storytelling.\"\n\nThe award comes as we're in production for the second season of 'The Lost Kingdom,' which is scheduled to premiere later this year. According to Lani, \"The team is energized by this recognition, and I can promise that the upcoming season will take the story and animation quality to even greater heights.\"\n\nWe're incredibly grateful for this honor and remain committed to creating animated content that inspires imagination and resonates with audiences worldwide. Stay tuned for more updates on Season 2 and other exciting projects in development at Mtaanimation!",
        thumbnailUrl: "https://images.unsplash.com/photo-1633412879581-c21cb88d3a4a?q=80&w=400",
        category: "Studio Updates",
        date: "2023-02-12",
        author: "Fredrick Lani"
      },
      {
        title: "The Art of Background Animation: Creating Immersive Worlds",
        excerpt: "Explore how our background artists craft the immersive environments that bring our animated series to life.",
        content: "While characters often steal the spotlight, the environments they inhabit are equally crucial to storytelling in animation. At Mtaanimation, our background and environment artists are world-builders in the truest sense, crafting visually stunning landscapes that enhance narrative and emotional impact.\n\nThe process begins with extensive concept art and mood boards that establish the visual language for each location. For 'The Lost Kingdom,' our team created detailed style guides for different regions, from the lush Emerald Forests to the imposing Ancient Citadel, each with distinct architectural elements, color palettes, and lighting schemes.\n\nParallax techniques are employed to create depth and dimension in our 2D animations. By separating background elements into multiple layers that move at different speeds, we achieve a sense of depth that draws viewers into the world. The ancient temples in Episode 14 featured over 20 separate parallax layers to create their imposing sense of scale and depth.\n\nWeather and atmospheric effects are another crucial component of our environment design. The storm sequence in Episode 12 required our effects team to develop new techniques for animating rain, lightning, and mist that integrated seamlessly with both characters and backgrounds.\n\nOur environments are also designed to evolve throughout the series, reflecting the passage of time and the impact of story events. Attentive viewers will notice subtle changes to recurring locations, with environments bearing the marks of previous encounters and battles.\n\nPerhaps most importantly, our background artists work closely with writers and directors to ensure that environments enhance storytelling. The architecture of the Forgotten Temple is designed to gradually reveal its history as characters venture deeper, with murals and structural elements that foreshadow plot developments.\n\nNext time you watch one of our series, we invite you to pay special attention to the environments. You'll discover a wealth of details and subtle storytelling elements that enhance the narrative and bring our animated worlds to life.",
        thumbnailUrl: "https://images.unsplash.com/photo-1493804714600-6edb1cd93080?q=80&w=400",
        category: "Animation Process",
        date: "2023-01-28",
        author: "Tanner Kawahara"
      }
    ];
    
    // Seed series
    console.log("Seeding series...");
    for (const series of seriesData) {
      try {
        const validatedData = schema.seriesInsertSchema.parse(series);
        await db.insert(schema.series).values(validatedData).onConflictDoNothing();
      } catch (error) {
        console.error(`Error validating or inserting series ${series.name}:`, error);
      }
    }
    
    // Seed episodes
    console.log("Seeding episodes...");
    for (const episode of episodesData) {
      try {
        const validatedData = schema.episodesInsertSchema.parse(episode);
        await db.insert(schema.episodes).values(validatedData).onConflictDoNothing();
      } catch (error) {
        console.error(`Error validating or inserting episode ${episode.title}:`, error);
      }
    }
    
    // Seed characters
    console.log("Seeding characters...");
    for (const character of charactersData) {
      try {
        const validatedData = schema.charactersInsertSchema.parse(character);
        await db.insert(schema.characters).values(validatedData).onConflictDoNothing();
      } catch (error) {
        console.error(`Error validating or inserting character ${character.name}:`, error);
      }
    }
    
    // Seed blog posts
    console.log("Seeding blog posts...");
    for (const post of blogPostsData) {
      try {
        const validatedData = schema.blogPostsInsertSchema.parse(post);
        await db.insert(schema.blogPosts).values(validatedData).onConflictDoNothing();
      } catch (error) {
        console.error(`Error validating or inserting blog post ${post.title}:`, error);
      }
    }
    
    console.log("Seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();