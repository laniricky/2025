import { Route, Switch, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/ui/theme-provider";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Episodes from "@/pages/Episodes";
import EpisodeDetail from "@/pages/EpisodeDetail";
import Characters from "@/pages/Characters";
import About from "@/pages/About";
import Blog from "@/pages/Blog";
import Contact from "@/pages/Contact";
import MainLayout from "./components/layout/MainLayout";
import AdminLayout from "./components/layout/AdminLayout";

// Admin pages
import AdminDashboard from "@/pages/admin/Dashboard";
import SeriesPage from "@/pages/admin/SeriesPage";
import SeriesForm from "@/pages/admin/SeriesForm";

function AdminRouter() {
  return (
    <Switch>
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/series" component={SeriesPage} />
      <Route path="/admin/series/new" component={SeriesForm} />
      <Route path="/admin/series/:id/edit" component={SeriesForm} />
      <Route component={NotFound} />
    </Switch>
  );
}

function MainRouter() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/episodes" component={Episodes} />
      <Route path="/episodes/:id" component={EpisodeDetail} />
      <Route path="/characters" component={Characters} />
      <Route path="/about" component={About} />
      <Route path="/blog" component={Blog} />
      <Route path="/contact" component={Contact} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [location] = useLocation();
  const isAdminRoute = location.startsWith("/admin");

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        {isAdminRoute ? (
          <AdminLayout>
            <AdminRouter />
          </AdminLayout>
        ) : (
          <MainLayout>
            <MainRouter />
          </MainLayout>
        )}
        <Toaster />
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
