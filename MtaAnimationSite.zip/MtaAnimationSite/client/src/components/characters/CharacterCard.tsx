import { Link } from "wouter";
import { Character } from "@/types";

interface CharacterCardProps {
  character: Character;
}

export default function CharacterCard({ character }: CharacterCardProps) {
  let gradientClass = "from-primary/20";
  
  if (character.color === "secondary") {
    gradientClass = "from-secondary/20";
  } else if (character.color === "accent") {
    gradientClass = "from-accent/20";
  }

  return (
    <div className="group">
      <Link href={`/characters/${character.id}`}>
        <div className={`relative overflow-hidden rounded-lg aspect-[3/4] bg-gradient-to-b ${gradientClass} to-card mb-3`}>
          <img
            src={character.imageUrl}
            alt={`${character.name} portrait`}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent"></div>
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <h3 className="font-bold text-lg text-white">{character.name}</h3>
            <p className="text-sm text-gray-300">{character.role}</p>
          </div>
        </div>
      </Link>
    </div>
  );
}
