import { Link } from "wouter";
import { Play } from "lucide-react";
import { Episode } from "@/types";
import { formatDate } from "@/lib/utils";

interface EpisodeCardProps {
  episode: Episode;
}

export default function EpisodeCard({ episode }: EpisodeCardProps) {
  return (
    <div className="bg-card rounded-lg overflow-hidden border border-border group hover:border-muted-foreground transition">
      <div className="relative aspect-video">
        <img
          src={episode.thumbnailUrl}
          alt={`${episode.title} thumbnail`}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card/80 to-transparent opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
          <Link href={`/episodes/${episode.id}`}>
            <button className="bg-primary/80 hover:bg-primary text-white h-12 w-12 rounded-full flex items-center justify-center">
              <Play className="h-5 w-5" />
            </button>
          </Link>
        </div>
        <span className="absolute top-2 right-2 bg-background/80 text-foreground text-xs px-2 py-1 rounded">
          {episode.duration}
        </span>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-lg mb-1">
          <Link href={`/episodes/${episode.id}`}>{episode.title}</Link>
        </h3>
        <p className="text-muted-foreground text-sm mb-2">
          {formatDate(episode.releaseDate)}
        </p>
        <p className="text-muted-foreground text-sm line-clamp-2">
          {episode.description}
        </p>
      </div>
    </div>
  );
}
