import { useState } from "react";
import { cn } from "@/lib/utils";
import { Play, Pause, Volume2, VolumeX } from "lucide-react";

interface VideoPlayerProps {
  videoUrl: string;
  title: string;
  className?: string;
  poster?: string;
}

export function VideoPlayer({ videoUrl, title, className, poster }: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [videoElement, setVideoElement] = useState<HTMLVideoElement | null>(null);

  const togglePlay = () => {
    if (!videoElement) return;
    
    if (isPlaying) {
      videoElement.pause();
    } else {
      videoElement.play();
    }
    
    setIsPlaying(!isPlaying);
  };

  const toggleMute = () => {
    if (!videoElement) return;
    
    videoElement.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleVideoEnd = () => {
    setIsPlaying(false);
  };

  return (
    <div className={cn("relative rounded-lg overflow-hidden bg-black", className)}>
      <video
        ref={setVideoElement}
        className="w-full aspect-video object-contain"
        src={videoUrl}
        poster={poster}
        onEnded={handleVideoEnd}
        controls={false}
      />
      
      <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 hover:opacity-100 transition-opacity">
        <button
          onClick={togglePlay}
          className="bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white h-16 w-16 rounded-full flex items-center justify-center transition"
        >
          {isPlaying ? (
            <Pause className="h-8 w-8" />
          ) : (
            <Play className="h-8 w-8" />
          )}
        </button>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 flex justify-between items-center">
        <div>
          <h3 className="text-lg font-medium text-white">{title}</h3>
        </div>
        <button
          onClick={toggleMute}
          className="text-white hover:text-accent transition"
        >
          {isMuted ? (
            <VolumeX className="h-5 w-5" />
          ) : (
            <Volume2 className="h-5 w-5" />
          )}
        </button>
      </div>
    </div>
  );
}
