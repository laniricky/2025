import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import BlogCard from "../blog/BlogCard";
import { BlogPost } from "@/types";

interface BlogPreviewProps {
  posts: BlogPost[];
}

export default function BlogPreview({ posts }: BlogPreviewProps) {
  return (
    <section className="py-12 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold">From Our Blog</h2>
          <Link
            href="/blog"
            className="text-accent hover:text-accent/80 font-medium flex items-center transition"
          >
            Read More
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post) => (
            <BlogCard key={post.id} post={post} />
          ))}
        </div>
      </div>
    </section>
  );
}
