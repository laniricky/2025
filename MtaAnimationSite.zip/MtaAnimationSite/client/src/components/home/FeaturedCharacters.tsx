import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import CharacterCard from "../characters/CharacterCard";
import { Character } from "@/types";

interface FeaturedCharactersProps {
  characters: Character[];
}

export default function FeaturedCharacters({ characters }: FeaturedCharactersProps) {
  return (
    <section className="py-12 bg-gradient-to-b from-background to-card">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold">Featured Characters</h2>
          <Link
            href="/characters"
            className="text-accent hover:text-accent/80 font-medium flex items-center transition"
          >
            View All
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {characters.map((character) => (
            <CharacterCard key={character.id} character={character} />
          ))}
        </div>
      </div>
    </section>
  );
}
