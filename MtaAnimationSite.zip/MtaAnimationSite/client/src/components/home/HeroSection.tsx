import { Link } from "wouter";
import { Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Episode } from "@/types";

interface HeroSectionProps {
  featuredEpisode: Episode;
}

export default function HeroSection({ featuredEpisode }: HeroSectionProps) {
  return (
    <section className="relative bg-gradient-to-br from-background to-card overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1608659597669-b45511779f93?q=80&w=1920')] bg-cover bg-center opacity-20"></div>
      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-1/2 space-y-6">
            <h1 className="text-4xl md:text-6xl font-bold font-accent leading-tight">
              <span className="text-secondary">Create.</span>{" "}
              <span className="text-accent">Imagine.</span>{" "}
              <span className="text-primary">Animate.</span>
            </h1>
            <p className="text-xl text-muted-foreground">
              Award-winning animations that tell compelling stories and inspire
              imagination.
            </p>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 pt-4">
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20"
                asChild
              >
                <Link href={`/episodes/${featuredEpisode.id}`}>
                  Watch Latest Episode
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-border hover:border-muted-foreground text-muted-foreground hover:text-foreground"
                asChild
              >
                <Link href="/episodes">Explore Series</Link>
              </Button>
            </div>
          </div>
          <div className="w-full md:w-1/2 mt-10 md:mt-0">
            <div className="relative aspect-video rounded-lg overflow-hidden shadow-2xl shadow-primary/20 border border-border">
              <img
                src={featuredEpisode.thumbnailUrl}
                alt={featuredEpisode.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 flex items-center justify-center bg-background/50">
                <Button
                  size="icon"
                  className="h-16 w-16 rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white"
                  asChild
                >
                  <Link href={`/episodes/${featuredEpisode.id}`}>
                    <Play className="h-8 w-8" />
                  </Link>
                </Button>
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                <h3 className="text-lg font-medium text-white">
                  {featuredEpisode.title}
                </h3>
                <p className="text-sm text-gray-300">
                  Released: {new Date(featuredEpisode.releaseDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
