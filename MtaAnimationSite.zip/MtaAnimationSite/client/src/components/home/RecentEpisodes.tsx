import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import EpisodeCard from "../episodes/EpisodeCard";
import { Episode } from "@/types";

interface RecentEpisodesProps {
  episodes: Episode[];
}

export default function RecentEpisodes({ episodes }: RecentEpisodesProps) {
  return (
    <section className="py-12 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl md:text-3xl font-bold">Recent Episodes</h2>
          <Link
            href="/episodes"
            className="text-accent hover:text-accent/80 font-medium flex items-center transition"
          >
            View All
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {episodes.map((episode) => (
            <EpisodeCard key={episode.id} episode={episode} />
          ))}
        </div>
      </div>
    </section>
  );
}
