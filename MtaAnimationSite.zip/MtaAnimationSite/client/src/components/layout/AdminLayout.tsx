import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Film, 
  Users, 
  FileText, 
  Tv2, 
  Settings,
  LogOut, 
  ChevronLeft, 
  Menu,
  X,
  Moon,
  Sun
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useMobile } from "@/hooks/use-mobile";
import { useTheme } from "@/components/ui/theme-provider";

interface AdminLayoutProps {
  children: React.ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const [location] = useLocation();
  const { isMobile } = useMobile();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();

  const menuItems = [
    {
      title: "Dashboard",
      href: "/admin",
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      title: "Series",
      href: "/admin/series",
      icon: <Tv2 className="h-5 w-5" />,
    },
    {
      title: "Episodes",
      href: "/admin/episodes",
      icon: <Film className="h-5 w-5" />,
    },
    {
      title: "Characters",
      href: "/admin/characters",
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: "Blog Posts",
      href: "/admin/blog-posts",
      icon: <FileText className="h-5 w-5" />,
    },
  ];

  const isActivePath = (path: string) => {
    if (path === "/admin") {
      return location === path;
    }
    return location.startsWith(path);
  };

  const SidebarContent = () => (
    <div className="flex h-full flex-col">
      <div className="flex items-center px-4 py-5">
        <Link href="/" className="flex items-center gap-2 font-bold text-xl">
          <span className="text-primary">Mtaanimation</span>
          <span className="text-xs bg-primary text-white px-2 py-0.5 rounded">
            Admin
          </span>
        </Link>
      </div>
      <Separator />

      <ScrollArea className="flex-1 py-4">
        <nav className="grid gap-1 px-2">
          {menuItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <Button
                variant={isActivePath(item.href) ? "secondary" : "ghost"}
                className={`w-full justify-start ${
                  isActivePath(item.href) ? "font-medium" : ""
                }`}
                onClick={() => isMobile && setSidebarOpen(false)}
              >
                {item.icon}
                <span className="ml-3">{item.title}</span>
              </Button>
            </Link>
          ))}
        </nav>
      </ScrollArea>

      <div className="mt-auto px-2 py-4">
        <Link href="/admin/settings">
          <Button 
            variant="ghost" 
            className="w-full justify-start"
            onClick={() => isMobile && setSidebarOpen(false)}
          >
            <Settings className="h-5 w-5" />
            <span className="ml-3">Settings</span>
          </Button>
        </Link>
        <Link href="/">
          <Button 
            variant="ghost" 
            className="w-full justify-start"
            onClick={() => isMobile && setSidebarOpen(false)}
          >
            <LogOut className="h-5 w-5" />
            <span className="ml-3">Back to Site</span>
          </Button>
        </Link>
        <Button 
          variant="ghost" 
          className="w-full justify-start mt-2" 
          onClick={toggleTheme}
        >
          {theme === 'dark' ? (
            <>
              <Sun className="h-5 w-5" />
              <span className="ml-3">Light Mode</span>
            </>
          ) : (
            <>
              <Moon className="h-5 w-5" />
              <span className="ml-3">Dark Mode</span>
            </>
          )}
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen">
      {/* Desktop sidebar */}
      {!isMobile && (
        <aside className="hidden w-64 shrink-0 border-r bg-background lg:block">
          <SidebarContent />
        </aside>
      )}

      {/* Mobile sidebar */}
      {isMobile && (
        <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="absolute left-4 top-4 z-50 lg:hidden"
            >
              {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0">
            <SidebarContent />
          </SheetContent>
        </Sheet>
      )}

      {/* Main content */}
      <main className="flex-1 bg-muted/20">
        <div className="container max-w-7xl py-10">
          {isMobile && (
            <div className="flex h-8 items-center mb-8">
              <Button
                variant="ghost"
                size="icon"
                className="mr-2"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                <Menu className="h-6 w-6" />
              </Button>
              <Link href="/" className="flex items-center gap-2 font-bold text-xl">
                <span className="text-primary">Mtaanimation</span>
                <span className="text-xs bg-primary text-white px-2 py-0.5 rounded">
                  Admin
                </span>
              </Link>
            </div>
          )}
          {children}
        </div>
      </main>
    </div>
  );
}