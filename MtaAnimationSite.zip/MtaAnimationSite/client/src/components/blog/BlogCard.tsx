import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { BlogPost } from "@/types";
import { formatDate } from "@/lib/utils";

interface BlogCardProps {
  post: BlogPost;
}

export default function BlogCard({ post }: BlogCardProps) {
  return (
    <article className="bg-card rounded-lg overflow-hidden border border-border">
      <img
        src={post.thumbnailUrl}
        alt={`${post.title} thumbnail`}
        className="w-full h-48 object-cover"
      />
      <div className="p-6">
        <div className="flex items-center text-muted-foreground text-sm mb-3">
          <span>{formatDate(post.date)}</span>
          <span className="mx-2">•</span>
          <span>{post.category}</span>
        </div>
        <h3 className="font-bold text-xl mb-3">{post.title}</h3>
        <p className="text-muted-foreground mb-4">{post.excerpt}</p>
        <Link
          href={`/blog/${post.id}`}
          className="text-accent hover:text-accent/80 font-medium inline-flex items-center transition"
        >
          Read Article
          <ArrowRight className="ml-2 h-4 w-4" />
        </Link>
      </div>
    </article>
  );
}
