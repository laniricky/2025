import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Episode } from "@/types";
import { VideoPlayer } from "@/components/ui/video-player";
import { formatDate } from "@/lib/utils";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import EpisodeCard from "@/components/episodes/EpisodeCard";

export default function EpisodeDetail() {
  const { id } = useParams();
  const episodeId = parseInt(id);

  const { data: episode, isLoading } = useQuery<Episode>({
    queryKey: [`/api/episodes/${episodeId}`],
  });

  const { data: relatedEpisodes = [] } = useQuery<Episode[]>({
    queryKey: ["/api/episodes"],
  });

  // Filter out current episode and get at most 4 episodes from the same series
  const filteredRelatedEpisodes = relatedEpisodes
    .filter(
      (ep) => ep.id !== episodeId && ep.seriesName === episode?.seriesName
    )
    .slice(0, 4);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <div className="animate-pulse">
          <div className="h-[40vh] bg-card rounded-lg mb-8"></div>
          <div className="h-8 w-2/3 mx-auto bg-card rounded mb-4"></div>
          <div className="h-4 w-1/3 mx-auto bg-card rounded mb-8"></div>
          <div className="h-20 bg-card rounded mb-4"></div>
        </div>
      </div>
    );
  }

  if (!episode) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Episode Not Found</h2>
        <p className="text-muted-foreground mb-6">
          The episode you're looking for doesn't exist or has been removed.
        </p>
        <Button asChild>
          <Link href="/episodes">Back to Episodes</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="mb-6">
        <Button variant="ghost" asChild className="mb-4">
          <Link href="/episodes">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Episodes
          </Link>
        </Button>
      </div>

      <VideoPlayer
        videoUrl={episode.videoUrl}
        title={episode.title}
        poster={episode.thumbnailUrl}
        className="mb-8 max-w-5xl mx-auto"
      />

      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl md:text-4xl font-bold mb-2">{episode.title}</h1>
        <div className="flex items-center text-muted-foreground text-sm mb-6">
          <span>{formatDate(episode.releaseDate)}</span>
          <span className="mx-2">•</span>
          <span>{episode.duration}</span>
          <span className="mx-2">•</span>
          <span>{episode.seriesName}</span>
        </div>

        <p className="text-lg mb-8">{episode.description}</p>

        <Separator className="my-10" />

        {filteredRelatedEpisodes.length > 0 && (
          <>
            <h2 className="text-2xl font-bold mb-6">More Episodes</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredRelatedEpisodes.map((relatedEpisode) => (
                <EpisodeCard key={relatedEpisode.id} episode={relatedEpisode} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
