import { Separator } from "@/components/ui/separator";

export default function About() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl md:text-4xl font-bold mb-6">About Mtaanimation</h1>
        
        <div className="relative w-full h-64 md:h-96 rounded-lg overflow-hidden mb-8">
          <img
            src="https://images.unsplash.com/photo-1611162616475-46b635cb6868?q=80&w=1920"
            alt="Animation studio"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent opacity-50"></div>
        </div>

        <div className="prose prose-lg dark:prose-invert max-w-none">
          <h2>Our Story</h2>
          <p>
            Founded in 2015 by creative director Fredrick Lani, Mtaanimation has grown from a small independent studio into an award-winning animation house. We specialize in creating compelling animated series that captivate audiences of all ages with their unique storytelling and distinctive visual style.
          </p>
          <p>
            Our team consists of passionate artists, animators, writers, and directors who share a common goal: to create animations that inspire imagination and leave a lasting impact on viewers. We believe in the power of animation to communicate complex ideas, evoke emotions, and transport audiences to new worlds.
          </p>
          
          <h2>Our Mission</h2>
          <p>
            At Mtaanimation, our mission is to push the boundaries of animated storytelling. We strive to create content that is not only visually stunning but also meaningful and thought-provoking. Through our animations, we aim to:
          </p>
          <ul>
            <li>Tell diverse and inclusive stories that resonate with audiences worldwide</li>
            <li>Explore complex themes and ideas through accessible and engaging narratives</li>
            <li>Innovate in animation techniques and visual styles</li>
            <li>Foster a community of animation enthusiasts and creators</li>
          </ul>
          
          <Separator className="my-10" />
          
          <div className="flex flex-col md:flex-row gap-8 items-start">
            <img
              src="https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?q=80&w=400"
              alt="Fredrick Lani"
              className="w-full md:w-64 aspect-square object-cover rounded-lg"
            />
            <div>
              <h2 className="mt-0">Meet the Creator: Fredrick Lani</h2>
              <p>
                Fredrick Lani, the founder and creative director of Mtaanimation, has been passionate about animation since childhood. Growing up watching classic animated films and series, he was inspired to pursue a career in animation and storytelling.
              </p>
              <p>
                After graduating from the International Academy of Art and Design, Fredrick worked at several major animation studios before founding Mtaanimation. His unique vision and creative approach have shaped the studio's distinctive style and storytelling philosophy.
              </p>
              <p>
                Fredrick believes in the power of animation to inspire and transform. His work often explores themes of adventure, self-discovery, and the importance of community. Under his guidance, Mtaanimation has produced multiple award-winning series and continues to push the boundaries of what animation can achieve.
              </p>
            </div>
          </div>

          <Separator className="my-10" />
          
          <h2>Our Achievements</h2>
          <p>
            Since our inception, Mtaanimation has been recognized for excellence in animation and storytelling. Some of our notable achievements include:
          </p>
          <ul>
            <li>Global Animation Award for "The Lost Kingdom" (2023)</li>
            <li>Best Animated Series at the International Film Festival (2022)</li>
            <li>Innovation in Animation Award (2021)</li>
            <li>Viewer's Choice Award for "Cosmic Adventures" (2020)</li>
            <li>Best Character Design for "Mythical Creatures" (2019)</li>
          </ul>
          
          <h2>Join Our Journey</h2>
          <p>
            We're always looking for talented individuals to join our team and contribute to our creative projects. Whether you're an animator, writer, designer, or passionate about animation in any capacity, we'd love to hear from you. Visit our contact page to get in touch with us about opportunities at Mtaanimation.
          </p>
          <p>
            Thank you for being part of our animation journey. We're excited to continue creating stories that inspire, entertain, and resonate with audiences around the world.
          </p>
        </div>
      </div>
    </div>
  );
}
