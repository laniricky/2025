import HeroSection from "@/components/home/HeroSection";
import RecentEpisodes from "@/components/home/RecentEpisodes";
import FeaturedCharacters from "@/components/home/FeaturedCharacters";
import BlogPreview from "@/components/home/BlogPreview";
import Newsletter from "@/components/home/Newsletter";
import { useQuery } from "@tanstack/react-query";
import { Episode, Character, BlogPost } from "@/types";

export default function Home() {
  const { data: episodes = [] } = useQuery<Episode[]>({
    queryKey: ["/api/episodes"],
  });

  const { data: characters = [] } = useQuery<Character[]>({
    queryKey: ["/api/characters"],
  });

  const { data: blogPosts = [] } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog-posts"],
  });

  // Get the latest episode for the hero section
  const featuredEpisode = episodes.length > 0 ? episodes[0] : {
    id: 1,
    title: "The Lost Kingdom: Episode 14",
    description: "The heroes face their greatest challenge yet as they venture deep into the forgotten temple.",
    thumbnailUrl: "https://images.unsplash.com/photo-1634986666676-ec8fd927c23d?q=80&w=800",
    videoUrl: "https://example.com/videos/episode-14.mp4",
    duration: "24:15",
    releaseDate: "2023-03-15",
    seriesName: "The Lost Kingdom"
  };

  // Get the 4 most recent episodes for the recent episodes section
  const recentEpisodes = episodes.slice(0, 4);

  // Get featured characters for the featured characters section
  const featuredCharacters = characters.slice(0, 4);

  // Get the 3 most recent blog posts for the blog preview section
  const recentBlogPosts = blogPosts.slice(0, 3);

  return (
    <>
      <HeroSection featuredEpisode={featuredEpisode} />
      <RecentEpisodes episodes={recentEpisodes} />
      <FeaturedCharacters characters={featuredCharacters} />
      <BlogPreview posts={recentBlogPosts} />
      <Newsletter />
    </>
  );
}
