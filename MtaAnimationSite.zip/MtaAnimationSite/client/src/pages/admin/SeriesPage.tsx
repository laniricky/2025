import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { PlusCircle, Pencil, Trash2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { type Series } from "@shared/schema";

export default function SeriesPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [seriesIdToDelete, setSeriesIdToDelete] = useState<number | null>(null);

  const { data: series, isLoading } = useQuery<Series[]>({
    queryKey: ['/api/series'],
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest('DELETE', `/api/admin/series/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/series'] });
      toast({
        title: "Series deleted",
        description: "The series has been successfully deleted.",
      });
      setSeriesIdToDelete(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete the series. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDeleteConfirm = () => {
    if (seriesIdToDelete !== null) {
      deleteMutation.mutate(seriesIdToDelete);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Series</h1>
          <p className="text-muted-foreground mt-2">
            Manage animation series in your content library.
          </p>
        </div>
        <Link href="/admin/series/new">
          <Button className="flex items-center gap-1">
            <PlusCircle className="h-4 w-4 mr-1" /> Add Series
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Series</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : series && series.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="w-[120px] text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {series.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell className="max-w-md truncate">{item.description}</TableCell>
                    <TableCell>
                      {new Date(item.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="text-right space-x-1">
                      <Link href={`/admin/series/${item.id}/edit`}>
                        <Button variant="ghost" size="icon">
                          <Pencil className="h-4 w-4" />
                        </Button>
                      </Link>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => setSeriesIdToDelete(item.id)}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No series found</p>
              <p className="text-sm text-muted-foreground mt-1">
                Get started by adding your first animation series
              </p>
              <Link href="/admin/series/new">
                <Button className="mt-4">
                  <PlusCircle className="h-4 w-4 mr-2" /> Add Series
                </Button>
              </Link>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <Dialog open={seriesIdToDelete !== null} onOpenChange={(open) => !open && setSeriesIdToDelete(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this series? This action cannot be undone.
              All related episodes and characters may also be affected.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSeriesIdToDelete(null)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteConfirm}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}