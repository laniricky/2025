import { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation, useParams, useRouter } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Loader2, ArrowLeft, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { type Series } from "@shared/schema";

// Form validation schema
const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
});

type FormData = z.infer<typeof formSchema>;

export default function SeriesForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  const params = useParams();
  const isEditing = params && params.id;
  
  // Fetch series data if editing
  const { data: seriesData, isLoading: isLoadingSeries } = useQuery<Series>({
    queryKey: ['/api/series', params.id],
    enabled: !!isEditing,
  });

  // Set up form with validation
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
    },
  });

  // Populate form when editing and data is loaded
  useEffect(() => {
    if (isEditing && seriesData) {
      form.reset({
        name: seriesData.name,
        description: seriesData.description,
      });
    }
  }, [form, isEditing, seriesData]);

  // Create mutation
  const createMutation = useMutation({
    mutationFn: (data: FormData) => 
      apiRequest('POST', '/api/admin/series', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/series'] });
      toast({
        title: "Series created",
        description: "New series has been successfully created.",
      });
      navigate("/admin/series");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create series. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update mutation
  const updateMutation = useMutation({
    mutationFn: (data: FormData) => 
      apiRequest('PUT', `/api/admin/series/${params.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/series'] });
      queryClient.invalidateQueries({ queryKey: ['/api/series', params.id] });
      toast({
        title: "Series updated",
        description: "Series has been successfully updated.",
      });
      navigate("/admin/series");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update series. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    if (isEditing) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Button 
            variant="ghost" 
            className="mb-4"
            onClick={() => navigate("/admin/series")}
          >
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Series
          </Button>
          <h1 className="text-3xl font-bold tracking-tight">
            {isEditing ? "Edit Series" : "Create New Series"}
          </h1>
          <p className="text-muted-foreground mt-2">
            {isEditing 
              ? "Update the details of this animation series" 
              : "Add a new animation series to your content library"}
          </p>
        </div>
      </div>

      {isEditing && isLoadingSeries ? (
        <div className="flex justify-center items-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="max-w-2xl">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Series Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter series name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter series description" 
                        className="min-h-[150px]"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end">
                <Button
                  type="button"
                  variant="outline"
                  className="mr-2"
                  onClick={() => navigate("/admin/series")}
                  disabled={isPending}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={isPending}>
                  {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  <Save className="mr-2 h-4 w-4" />
                  {isEditing ? "Update Series" : "Create Series"}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      )}
    </div>
  );
}