import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Film, Users, FileText, Tv2 } from "lucide-react";

export default function AdminDashboard() {
  const { data: series = [] } = useQuery<any[]>({
    queryKey: ['/api/series'],
  });

  const { data: episodes = [] } = useQuery<any[]>({
    queryKey: ['/api/episodes'],
  });

  const { data: characters = [] } = useQuery<any[]>({
    queryKey: ['/api/characters'],
  });

  const { data: blogPosts = [] } = useQuery<any[]>({
    queryKey: ['/api/blog-posts'],
  });

  const counts = {
    series: series.length || 0,
    episodes: episodes.length || 0,
    characters: characters.length || 0,
    blogPosts: blogPosts.length || 0,
  };

  const statCards = [
    { 
      title: 'Series', 
      count: counts.series, 
      description: 'Animation series in the database',
      icon: <Tv2 className="h-6 w-6" />,
      link: '/admin/series',
      color: 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300',
    },
    { 
      title: 'Episodes', 
      count: counts.episodes, 
      description: 'Total episodes across all series',
      icon: <Film className="h-6 w-6" />,
      link: '/admin/episodes',
      color: 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300',
    },
    { 
      title: 'Characters', 
      count: counts.characters, 
      description: 'Characters across all series',
      icon: <Users className="h-6 w-6" />,
      link: '/admin/characters',
      color: 'bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300',
    },
    { 
      title: 'Blog Posts', 
      count: counts.blogPosts, 
      description: 'Published blog articles',
      icon: <FileText className="h-6 w-6" />,
      link: '/admin/blog-posts',
      color: 'bg-amber-100 dark:bg-amber-900 text-amber-700 dark:text-amber-300',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Manage your animation content from this central dashboard.
        </p>
      </div>
      
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((card) => (
          <Card key={card.title} className="flex flex-col h-full">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-xl font-medium">{card.title}</CardTitle>
              <div className={`p-2 rounded-full ${card.color}`}>
                {card.icon}
              </div>
            </CardHeader>
            <CardContent className="py-4">
              <div className="text-4xl font-bold">{card.count}</div>
              <p className="text-sm text-muted-foreground mt-1">{card.description}</p>
            </CardContent>
            <CardFooter className="pt-0 mt-auto">
              <Link href={card.link}>
                <Button variant="outline" className="w-full">Manage {card.title}</Button>
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>
              Latest updates to your content
            </CardDescription>
          </CardHeader>
          <CardContent>
            {counts.episodes + counts.blogPosts > 0 ? (
              <div className="space-y-4">
                {episodes?.slice(0, 3).map((episode: any) => (
                  <div key={episode.id} className="flex items-center gap-4">
                    <div className={`p-2 rounded-full bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300`}>
                      <Film className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-medium">{episode.title}</p>
                      <p className="text-sm text-muted-foreground">Episode added on {new Date(episode.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))}
                {blogPosts?.slice(0, 2).map((post: any) => (
                  <div key={post.id} className="flex items-center gap-4">
                    <div className={`p-2 rounded-full bg-amber-100 dark:bg-amber-900 text-amber-700 dark:text-amber-300`}>
                      <FileText className="h-4 w-4" />
                    </div>
                    <div>
                      <p className="font-medium">{post.title}</p>
                      <p className="text-sm text-muted-foreground">Blog post published on {new Date(post.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-48 text-center">
                <p className="text-muted-foreground mb-2">No recent activity to display</p>
                <p className="text-sm text-muted-foreground">Start adding content to see updates here</p>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>
              Common tasks for content management
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-2">
              <Link href="/admin/episodes/new">
                <Button variant="outline" className="w-full justify-start">
                  <Film className="mr-2 h-4 w-4" /> Add New Episode
                </Button>
              </Link>
              <Link href="/admin/characters/new">
                <Button variant="outline" className="w-full justify-start">
                  <Users className="mr-2 h-4 w-4" /> Add New Character
                </Button>
              </Link>
              <Link href="/admin/blog-posts/new">
                <Button variant="outline" className="w-full justify-start">
                  <FileText className="mr-2 h-4 w-4" /> Write New Blog Post
                </Button>
              </Link>
              <Link href="/admin/series/new">
                <Button variant="outline" className="w-full justify-start">
                  <Tv2 className="mr-2 h-4 w-4" /> Add New Series
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}