export interface Episode {
  id: number;
  title: string;
  description: string;
  thumbnailUrl: string;
  videoUrl: string;
  duration: string;
  releaseDate: string;
  seriesName: string;
}

export interface Character {
  id: number;
  name: string;
  role: string;
  description: string;
  imageUrl: string;
  seriesName: string;
  color: string;
}

export interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  thumbnailUrl: string;
  category: string;
  date: string;
  author: string;
}

export interface Series {
  id: number;
  name: string;
  description: string;
}

export type ThemeType = "dark" | "light";
